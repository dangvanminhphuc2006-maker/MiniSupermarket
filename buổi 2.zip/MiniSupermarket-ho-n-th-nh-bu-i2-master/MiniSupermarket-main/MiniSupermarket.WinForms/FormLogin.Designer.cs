﻿using System;
using System.Drawing;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Windows.Forms;

namespace MiniSupermarket.WinForms
{
    public partial class FormLogin : Form
    {
        private static readonly HttpClient _client = new HttpClient
        {
            BaseAddress = new Uri("https://localhost:7054/api/") // Đã chỉnh đúng Port 7054
        };

        // Khai báo các Control
        private TextBox txtUser = null!;
        private TextBox txtPass = null!;
        private Button btnLogin = null!;
        private Label lblUser = null!;
        private Label lblPass = null!;

        public FormLogin()
        {
            InitializeComponent();
            BuildUI(); // Tự động dựng giao diện bằng code
        }

        // Tự động vẽ giao diện đăng nhập
        private void BuildUI()
        {
            this.Text = "Đăng nhập Hệ thống";
            this.Size = new Size(350, 230);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            lblUser = new Label { Text = "Tài khoản:", Location = new Point(30, 30), AutoSize = true };
            txtUser = new TextBox { Location = new Point(120, 27), Size = new Size(170, 25) };

            lblPass = new Label { Text = "Mật khẩu:", Location = new Point(30, 70), AutoSize = true };
            txtPass = new TextBox { Location = new Point(120, 67), Size = new Size(170, 25), PasswordChar = '*' };

            btnLogin = new Button { Text = "Đăng nhập", Location = new Point(120, 110), Size = new Size(170, 35) };
            btnLogin.Click += btnLogin_Click;

            this.Controls.Add(lblUser);
            this.Controls.Add(txtUser);
            this.Controls.Add(lblPass);
            this.Controls.Add(txtPass);
            this.Controls.Add(btnLogin);
        }

        // Sự kiện Đăng nhập
        private async void btnLogin_Click(object? sender, EventArgs e)
        {
            string username = txtUser.Text.Trim();
            string password = txtPass.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ tài khoản và mật khẩu!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                var loginData = new { Username = username, Password = password };
                var response = await _client.PostAsJsonAsync("auth/login", loginData);

                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(jsonString);

                    SessionManager.JwtToken = doc.RootElement.GetProperty("token").GetString() ?? string.Empty;
                    SessionManager.CurrentRole = doc.RootElement.GetProperty("role").GetString() ?? string.Empty;

                    MessageBox.Show($"Đăng nhập thành công với quyền: {SessionManager.CurrentRole}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    FormCategoryManagement mainForm = new FormCategoryManagement();
                    this.Hide();
                    mainForm.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Sai tài khoản hoặc mật khẩu!", "Đăng nhập thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối đến Server: " + ex.Message, "Lỗi hệ thống", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}