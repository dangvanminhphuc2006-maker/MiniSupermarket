﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniSupermarket.WinForms
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        // =====================================================
        // BƯỚC 3: SỰ KIỆN NÚT ĐĂNG NHẬP
        // =====================================================
        private async void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // Kiểm tra đầu vào
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Tên đăng nhập và Mật khẩu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi hàm xử lý đăng nhập
            bool isSuccess = await PerformLoginAsync(username, password);

            // Nếu thành công -> Chuyển sang FormCategoryManagement
            if (isSuccess)
            {
                MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide(); // Ẩn FormLogin

                FormCategoryManagement categoryForm = new FormCategoryManagement();

                // Khi đóng FormCategoryManagement thì ứng dụng sẽ đóng hoàn toàn
                categoryForm.FormClosed += (s, args) => this.Close();

                categoryForm.Show();
            }
        }

        // =====================================================
        // BƯỚC 4: HÀM GỌI API ĐĂNG NHẬP
        // =====================================================
        private async Task<bool> PerformLoginAsync(string username, string password)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    // LƯU Ý: Sửa lại đúng port Backend API của bạn (ví dụ: 7054)
                    client.BaseAddress = new Uri("https://localhost:7054/api/");

                    var loginData = new LoginRequest
                    {
                        Username = username,
                        Password = password
                    };

                    // Gọi API Post
                    HttpResponseMessage response = await client.PostAsJsonAsync("Auth/login", loginData);

                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadFromJsonAsync<LoginResponse>();

                        if (result != null && !string.IsNullOrEmpty(result.Token))
                        {
                            // Lưu JwtToken vào SessionManager
                            SessionManager.JwtToken = result.Token;
                            return true;
                        }
                    }

                    MessageBox.Show("Tài khoản hoặc mật khẩu không chính xác!", "Đăng nhập thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối đến Server API: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
    }

    // =====================================================
    // BƯỚC 2: CÁC CLASS DTO GỬI VÀ NHẬN DỮ LIỆU API
    // =====================================================
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class LoginResponse
    {
        public string Token { get; set; }
        public string Message { get; set; }
    }
}